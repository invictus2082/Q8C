Development moved to https://gitlab.com/blacknet-ninja

https://q8exchangecoin.org/ aims to continue on Q8exchangeCoin chain.
